import { PrismaClient } from '../generated/client/index.js';

const prisma = new PrismaClient();

export default prisma;