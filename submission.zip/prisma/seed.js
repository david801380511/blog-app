import { PrismaClient } from "../src/generated/client/index.js";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  await prisma.post.deleteMany();
  await prisma.user.deleteMany();

  const usersData = [
    {
      email: "alice@test.com",
      password: await bcrypt.hash("alice1234", 10),
    },
    {
      email: "bob@example.com",
      password: await bcrypt.hash("bob1234", 10),
    },
    {
      email: "charlie@demo.com",
      password: await bcrypt.hash("charlie1234", 10),
      role: "ADMIN",
    },
  ];

  await Promise.all(usersData.map((user) => prisma.user.create({ data: user })));
  console.log("Seed complete: users created");
}

main()
  .catch((e) => {
    console.error("Seed failed:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
